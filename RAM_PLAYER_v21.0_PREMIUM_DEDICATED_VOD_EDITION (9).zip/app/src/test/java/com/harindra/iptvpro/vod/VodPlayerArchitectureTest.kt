package com.harindra.iptvpro.vod

import android.view.KeyEvent
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

/**
 * Comprehensive JVM Unit Tests for RAM PLAYER v21.0 Dedicated VOD Player Architecture.
 */
class VodPlayerArchitectureTest {

    @Test
    fun seekControllerSupportsAllIntervalsAndClampsToDuration() {
        val controller = VodSeekController(VodSeekInterval.SEC_10)
        assertEquals(10_000L, controller.getDefaultInterval().millis)

        val forward = controller.computeStepSeek(
            currentPositionMs = 30_000L,
            durationMs = 120_000L,
            isSeekable = true,
            isForward = true
        )
        assertNotNull(forward)
        assertEquals(40_000L, forward!!.targetPositionMs)
        assertEquals(10_000L, forward.deltaMs)

        val rewindClamped = controller.computeStepSeek(
            currentPositionMs = 5_000L,
            durationMs = 120_000L,
            isSeekable = true,
            isForward = false
        )
        assertNotNull(rewindClamped)
        assertEquals(0L, rewindClamped!!.targetPositionMs)

        controller.setDefaultInterval(VodSeekInterval.SEC_60)
        val forwardClamped = controller.computeStepSeek(
            currentPositionMs = 100_000L,
            durationMs = 120_000L,
            isSeekable = true,
            isForward = true
        )
        assertEquals(120_000L, forwardClamped!!.targetPositionMs)

        val unseekable = controller.computeStepSeek(
            currentPositionMs = 10_000L,
            durationMs = 0L,
            isSeekable = false,
            isForward = true
        )
        assertNull(unseekable)
    }

    @Test
    fun seekControllerContinuousLongPressAcceleratesAndCommits() {
        val controller = VodSeekController(VodSeekInterval.SEC_10)
        var lastPreview: VodSeekPreviewState? = null
        for (i in 1..6) {
            lastPreview = controller.onContinuousSeekStep(
                currentPositionMs = 100_000L,
                durationMs = 3_600_000L,
                isSeekable = true,
                isForward = true
            )
        }
        assertTrue(controller.isContinuousScrubbing())
        assertNotNull(lastPreview)
        // Steps 1-4 = +10s each (40s), steps 5-6 = +20s each (40s) => +80s total
        assertEquals(180_000L, lastPreview!!.targetPositionMs)

        val committed = controller.commitContinuousSeek()
        assertEquals(180_000L, committed)
        assertFalse(controller.isContinuousScrubbing())
    }

    @Test
    fun progressStoreSeparatesMoviesAndEpisodesAndDetectsCompletion() {
        val storage = InMemoryVodProgressStorage()
        val store = VodProgressStore(storage)

        // Too short (<10s) must not be saved
        val ignored = store.recordProgress(
            contentType = VodContentType.MOVIE,
            contentId = "vod_101",
            positionMs = 4_000L,
            durationMs = 5_400_000L,
            accountScope = "acc1"
        )
        assertFalse(ignored.saved)

        // Valid movie progress saved and resumable
        val savedMovie = store.recordProgress(
            contentType = VodContentType.MOVIE,
            contentId = "vod_101",
            positionMs = 1_200_000L,
            durationMs = 5_400_000L,
            accountScope = "acc1",
            nowMs = 1000L
        )
        assertTrue(savedMovie.saved)
        assertFalse(savedMovie.markedCompleted)
        assertEquals(1_200_000L, store.getResumePositionMs("vod_101", "acc1", resumeEnabled = true))
        assertEquals(0L, store.getResumePositionMs("vod_101", "acc1", resumeEnabled = false))

        // Independent episode progress for S1E1 and S1E2
        store.recordProgress(
            contentType = VodContentType.SERIES_EPISODE,
            contentId = "ep_1",
            positionMs = 600_000L,
            durationMs = 2_400_000L,
            accountScope = "acc1",
            seriesKey = "xtream_series_55",
            seasonNumber = 1,
            episodeNumber = 1,
            nowMs = 2000L
        )
        store.recordProgress(
            contentType = VodContentType.SERIES_EPISODE,
            contentId = "ep_2",
            positionMs = 900_000L,
            durationMs = 2_400_000L,
            accountScope = "acc1",
            seriesKey = "xtream_series_55",
            seasonNumber = 1,
            episodeNumber = 2,
            nowMs = 3000L
        )
        assertEquals(1, store.getContinueWatchingMovies("acc1").size)
        assertEquals(2, store.getContinueWatchingSeries("acc1").size)
        assertEquals("ep_2", store.getLatestEpisodeForSeries("xtream_series_55", "acc1")?.contentId)

        // Movie reaches >=92% -> marked completed & removed from Continue Watching
        val completed = store.recordProgress(
            contentType = VodContentType.MOVIE,
            contentId = "vod_101",
            positionMs = 5_100_000L,
            durationMs = 5_400_000L,
            accountScope = "acc1"
        )
        assertTrue(completed.markedCompleted)
        assertTrue(store.isCompleted("vod_101", "acc1"))
        assertEquals(0, store.getContinueWatchingMovies("acc1").size)

        // Rewatch resets completion & progress
        store.resetForRewatch("vod_101", "acc1")
        assertFalse(store.isCompleted("vod_101", "acc1"))
    }

    @Test
    fun autoNextTriggersExactlyOnceAndCrossesSeasonsCorrectly() {
        val episodes = listOf(
            VodEpisodeNavItem("ep_s1e1", "55", "sk_55", "Drama", 1, 1, "Pilot", "http://x/1.mp4"),
            VodEpisodeNavItem("ep_s1e2", "55", "sk_55", "Drama", 1, 2, "Finale", "http://x/2.mp4"),
            VodEpisodeNavItem("ep_s2e1", "55", "sk_55", "Drama", 2, 1, "Return", "http://x/3.mp4")
        )
        val controller = VodAutoNextController(episodes)

        assertEquals("ep_s1e2", controller.findNextEpisode("ep_s1e1")?.episodeId)
        assertEquals("ep_s2e1", controller.findNextEpisode("ep_s1e2")?.episodeId)
        assertNull(controller.findNextEpisode("ep_s2e1"))
        assertEquals("ep_s1e2", controller.findPreviousEpisode("ep_s2e1")?.episodeId)

        // First trigger near end succeeds
        val firstTrigger = controller.evaluateAutoNextTrigger(
            contentType = VodContentType.SERIES_EPISODE,
            currentEpisodeId = "ep_s1e1",
            positionMs = 2_390_000L,
            durationMs = 2_400_000L,
            playbackEnded = false,
            autoNextEnabled = true
        )
        assertNotNull(firstTrigger)
        assertEquals("ep_s1e2", firstTrigger!!.episodeId)

        // Second evaluation for same episode MUST NOT trigger again
        val secondTrigger = controller.evaluateAutoNextTrigger(
            contentType = VodContentType.SERIES_EPISODE,
            currentEpisodeId = "ep_s1e1",
            positionMs = 2_400_000L,
            durationMs = 2_400_000L,
            playbackEnded = true,
            autoNextEnabled = true
        )
        assertNull(secondTrigger)

        // Movies never trigger auto-next
        val movieTrigger = controller.evaluateAutoNextTrigger(
            contentType = VodContentType.MOVIE,
            currentEpisodeId = "ep_s1e2",
            positionMs = 2_400_000L,
            durationMs = 2_400_000L,
            playbackEnded = true,
            autoNextEnabled = true
        )
        assertNull(movieTrigger)
    }

    @Test
    fun errorHandlerClassifiesFatalVsRetryableAndCapsRetries() {
        val handler = VodPlaybackErrorHandler(maxTransientRetries = 3)

        val authErr = handler.classifyHttpStatus(401)
        assertEquals(VodErrorCategory.AUTH_EXPIRED, authErr.category)
        assertFalse(authErr.canRetry)
        assertNull(handler.nextRetryDelayMs(authErr))

        val notFound = handler.classifyHttpStatus(404)
        assertEquals(VodErrorCategory.NOT_FOUND, notFound.category)
        assertFalse(notFound.canRetry)

        val serverErr = handler.classifyHttpStatus(503)
        assertEquals(VodErrorCategory.SERVER_ERROR, serverErr.category)
        assertTrue(serverErr.canRetry)

        assertNotNull(handler.nextRetryDelayMs(serverErr))
        assertNotNull(handler.nextRetryDelayMs(serverErr))
        assertNotNull(handler.nextRetryDelayMs(serverErr))
        // 4th retry MUST be blocked — never infinite loops
        assertNull(handler.nextRetryDelayMs(serverErr))
    }

    @Test
    fun preferencesStorePersistsAllVodSettingsIndependently() {
        val prefs = VodPreferencesStore(InMemoryVodPreferencesBacking())
        prefs.setDefaultSeekInterval(VodSeekInterval.SEC_30)
        prefs.setDefaultPlaybackSpeed(VodPlaybackSpeed.SPEED_1_5)
        prefs.setDefaultQualityMode("1080p Full HD")
        prefs.setPreferredAudioLanguage("hi")
        prefs.setPreferredSubtitleLanguage("en")
        prefs.setSubtitlesDefaultEnabled(true)
        prefs.setSubtitleFontSize(VodSubtitleFontSize.LARGE)
        prefs.setSubtitleStylePreset(VodSubtitleStylePreset.HIGH_CONTRAST_YELLOW)
        prefs.setSubtitleDelayMs(500)
        prefs.setAspectRatioMode(VodAspectRatioMode.ZOOM)
        prefs.setAutoNextEpisodeEnabled(false)
        prefs.setAutoNextCountdownSec(15)
        prefs.setResumePlaybackEnabled(false)
        prefs.setControlsAutoHideMs(8_000L)

        assertEquals(VodSeekInterval.SEC_30, prefs.getDefaultSeekInterval())
        assertEquals(VodPlaybackSpeed.SPEED_1_5, prefs.getDefaultPlaybackSpeed())
        assertEquals("1080p Full HD", prefs.getDefaultQualityMode())
        assertEquals("hi", prefs.getPreferredAudioLanguage())
        assertEquals("en", prefs.getPreferredSubtitleLanguage())
        assertTrue(prefs.isSubtitlesDefaultEnabled())
        assertEquals(VodSubtitleFontSize.LARGE, prefs.getSubtitleFontSize())
        assertEquals(VodSubtitleStylePreset.HIGH_CONTRAST_YELLOW, prefs.getSubtitleStylePreset())
        assertEquals(500, prefs.getSubtitleDelayMs())
        assertEquals(VodAspectRatioMode.ZOOM, prefs.getAspectRatioMode())
        assertFalse(prefs.isAutoNextEpisodeEnabled())
        assertEquals(15, prefs.getAutoNextCountdownSec())
        assertFalse(prefs.isResumePlaybackEnabled())
        assertEquals(8_000L, prefs.getControlsAutoHideMs())
    }

    @Test
    fun remoteControlRoutesTvKeysCleanlyWithoutLiveTvSideEffects() {
        val rc = VodRemoteControlController()

        // Hidden controls: OK reveals controls, Left/Right seek, Back exits
        assertEquals(
            VodRemoteAction.SHOW_CONTROLS_AND_FOCUS_PLAY,
            rc.onKeyDown(KeyEvent.KEYCODE_DPAD_CENTER, 0, controlsVisible = false, sidePanelOpen = false, errorOverlayVisible = false, autoNextVisible = false, seekBarFocused = false)
        )
        assertEquals(
            VodRemoteAction.SEEK_REWIND_STEP,
            rc.onKeyDown(KeyEvent.KEYCODE_DPAD_LEFT, 0, controlsVisible = false, sidePanelOpen = false, errorOverlayVisible = false, autoNextVisible = false, seekBarFocused = false)
        )
        assertEquals(
            VodRemoteAction.SEEK_FORWARD_CONTINUOUS,
            rc.onKeyDown(KeyEvent.KEYCODE_DPAD_RIGHT, 3, controlsVisible = false, sidePanelOpen = false, errorOverlayVisible = false, autoNextVisible = false, seekBarFocused = false)
        )
        assertEquals(
            VodRemoteAction.EXIT_VOD_PLAYER,
            rc.onKeyDown(KeyEvent.KEYCODE_BACK, 0, controlsVisible = false, sidePanelOpen = false, errorOverlayVisible = false, autoNextVisible = false, seekBarFocused = false)
        )

        // Visible controls: Back hides controls first instead of exiting
        assertEquals(
            VodRemoteAction.HIDE_CONTROLS,
            rc.onKeyDown(KeyEvent.KEYCODE_BACK, 0, controlsVisible = true, sidePanelOpen = false, errorOverlayVisible = false, autoNextVisible = false, seekBarFocused = false)
        )
        // Side panel open: Back closes side panel first
        assertEquals(
            VodRemoteAction.CLOSE_SIDE_PANEL,
            rc.onKeyDown(KeyEvent.KEYCODE_BACK, 0, controlsVisible = true, sidePanelOpen = true, errorOverlayVisible = false, autoNextVisible = false, seekBarFocused = false)
        )
        // Key up commits continuous scrubbing
        assertEquals(
            VodRemoteAction.COMMIT_CONTINUOUS_SEEK,
            rc.onKeyUp(KeyEvent.KEYCODE_DPAD_RIGHT, isContinuousScrubbing = true)
        )
    }

    @Test
    fun episodeNavItemJsonRoundTripAndTrackFormattersWork() {
        val list = listOf(
            VodEpisodeNavItem("ep_1", "10", "sk_10", "Show", 1, 1, "Ep 1", "http://example.com/1.mkv", "http://img/1.jpg", "42m")
        )
        val decoded = VodEpisodeNavItem.decodeList(VodEpisodeNavItem.encodeList(list))
        assertEquals(1, decoded.size)
        assertEquals("ep_1", decoded[0].episodeId)
        assertEquals("S01E01", decoded[0].seasonEpisodeBadge())

        assertEquals("2160p 4K", VodTrackSelectionManager.formatResolutionLabel(2160))
        assertEquals("1080p Full HD", VodTrackSelectionManager.formatResolutionLabel(1080))
        assertEquals("720p HD", VodTrackSelectionManager.formatResolutionLabel(720))
        assertEquals("Dolby Digital+", VodTrackSelectionManager.shortAudioCodec("audio/eac3", "ec-3"))
        assertEquals("5.1 Surround", VodTrackSelectionManager.channelLayoutLabel(6))
        assertEquals("1:05:30", VodTimeFormatter.formatMs(3_930_000L))
    }

    @Test
    fun proFeaturesControllerSkipIntroSleepTimerBoostAndJumpWork() {
        val pro = VodProFeaturesController()

        // Skip Intro eligibility & target
        assertTrue(pro.isSkipIntroEligible(positionMs = 30_000L, durationMs = 5_400_000L))
        assertFalse(pro.isSkipIntroEligible(positionMs = 300_000L, durationMs = 5_400_000L))
        assertEquals(115_000L, pro.computeSkipIntroTarget(positionMs = 30_000L, durationMs = 5_400_000L))

        // Quick Jump % and minute jumps
        assertEquals(2_700_000L, pro.computePercentJumpTarget(durationMs = 5_400_000L, percent = 50))
        assertEquals(360_000L, pro.computeMinuteJumpTarget(currentPositionMs = 60_000L, durationMs = 5_400_000L, deltaMinutes = 5))
        assertEquals(0L, pro.computeMinuteJumpTarget(currentPositionMs = 60_000L, durationMs = 5_400_000L, deltaMinutes = -5))

        // Screen lock & Nerd Stats toggle
        assertTrue(pro.toggleScreenLock())
        pro.unlockScreen()
        assertFalse(pro.isScreenLocked)
        assertTrue(pro.toggleNerdStats())

        // Audio boost & Night Dim cycling
        assertEquals(VodAudioBoostLevel.LOW, pro.cycleAudioBoost())
        assertEquals(VodNightDimLevel.SOFT, pro.cycleNightDim())

        // Sleep timer expiry & End of Title
        pro.setSleepTimer(VodSleepTimerMode.MIN_15, nowMs = 1_000L)
        assertFalse(pro.isSleepTimerExpired(nowMs = 100_000L))
        assertTrue(pro.isSleepTimerExpired(nowMs = 1_000L + 15 * 60_000L))
        pro.setSleepTimer(VodSleepTimerMode.END_OF_TITLE)
        assertTrue(pro.shouldStopAtTitleEnd())

        // Nerd Stats formatting
        val hud = pro.formatStatsHud(1920, 1080, 24f, "HEVC", "Hindi • AAC", 4_500_000, 18_000L, "1.0x")
        assertTrue(hud.contains("1920×1080"))
        assertTrue(hud.contains("HEVC"))
        assertTrue(hud.contains("+18s"))
    }

    @Test
    fun abLoopBookmarksPictureModeAndEndsAtClockWork() {
        val pro = VodProFeaturesController()

        // A-B Loop lifecycle
        assertEquals(VodAbLoopState.POINT_A_SET, pro.advanceAbLoop(10_000L))
        assertEquals(VodAbLoopState.LOOPING_AB, pro.advanceAbLoop(25_000L))
        assertFalse(pro.shouldLoopBackToA(20_000L))
        assertTrue(pro.shouldLoopBackToA(25_500L))
        assertEquals(VodAbLoopState.OFF, pro.advanceAbLoop(26_000L))

        // Scene Bookmarks
        pro.addBookmark(45_000L)
        pro.addBookmark(120_000L)
        assertEquals(2, pro.getBookmarks().size)
        assertEquals(45_000L, pro.getBookmarks()[0].positionMs)
        pro.clearBookmarks()
        assertEquals(0, pro.getBookmarks().size)

        // Picture modes & Micro-replay
        assertEquals(VodPictureMode.WARM_CINEMA, pro.cyclePictureMode())
        assertEquals(7_000L, pro.computeMicroReplayTarget(10_000L))
        assertEquals(0L, pro.computeMicroReplayTarget(1_500L))

        // Remaining / Ends-At clock toggle
        assertEquals("1:00:00", pro.formatDurationOrRemaining(600_000L, 3_600_000L))
        pro.toggleRemainingTimeDisplay()
        assertTrue(pro.formatDurationOrRemaining(600_000L, 3_600_000L).startsWith("-50:00"))
    }
}
