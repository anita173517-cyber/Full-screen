package com.harindra.iptvpro.vod

import com.harindra.iptvpro.ContentSourceType
import org.json.JSONArray
import org.json.JSONObject
import java.util.Locale

/**
 * RAM PLAYER v21.0 — Dedicated Premium VOD Player Models.
 * Strictly isolated from Live TV channel/EPG/zapping state.
 */
enum class VodContentType(val code: String) {
    MOVIE("MOVIE"),
    SERIES_EPISODE("SERIES_EPISODE");

    fun toContentSourceType(): ContentSourceType = when (this) {
        MOVIE -> ContentSourceType.XTREAM_VOD_MOVIE
        SERIES_EPISODE -> ContentSourceType.XTREAM_SERIES_EPISODE
    }

    companion object {
        fun fromCode(raw: String?): VodContentType {
            return values().firstOrNull { it.code.equals(raw?.trim(), ignoreCase = true) } ?: MOVIE
        }
    }
}

enum class VodSeekInterval(val seconds: Int, val label: String) {
    SEC_5(5, "5s"),
    SEC_10(10, "10s"),
    SEC_15(15, "15s"),
    SEC_20(20, "20s"),
    SEC_30(30, "30s"),
    SEC_60(60, "60s");

    val millis: Long get() = seconds * 1000L

    companion object {
        fun fromMillis(ms: Long): VodSeekInterval {
            return values().firstOrNull { it.millis == ms } ?: SEC_10
        }

        fun fromSeconds(sec: Int): VodSeekInterval {
            return values().firstOrNull { it.seconds == sec } ?: SEC_10
        }
    }
}

enum class VodPlaybackSpeed(val rate: Float, val label: String) {
    SPEED_0_5(0.5f, "0.5x"),
    SPEED_0_75(0.75f, "0.75x"),
    SPEED_1_0(1.0f, "1.0x"),
    SPEED_1_25(1.25f, "1.25x"),
    SPEED_1_5(1.5f, "1.5x"),
    SPEED_1_75(1.75f, "1.75x"),
    SPEED_2_0(2.0f, "2.0x");

    companion object {
        fun fromRate(rate: Float): VodPlaybackSpeed {
            return values().minByOrNull { kotlin.math.abs(it.rate - rate) } ?: SPEED_1_0
        }
    }
}

enum class VodAspectRatioMode(val id: String, val label: String, val description: String) {
    FIT("FIT", "Fit", "Preserve original video proportions inside screen"),
    FILL("FILL", "Fill", "Scale uniformly to fill screen"),
    ZOOM("ZOOM", "Zoom", "Crop edges slightly to eliminate black bars"),
    STRETCH("STRETCH", "Stretch", "Stretch video to exact screen edges"),
    ORIGINAL("ORIGINAL", "Original", "Native unscaled source aspect ratio");

    fun next(): VodAspectRatioMode {
        val all = values()
        return all[(ordinal + 1) % all.size]
    }

    companion object {
        fun fromId(id: String?): VodAspectRatioMode {
            return values().firstOrNull { it.id.equals(id?.trim(), ignoreCase = true) } ?: FIT
        }
    }
}

enum class VodSubtitleFontSize(val id: String, val label: String, val textSizeSp: Float, val fractionalSize: Float) {
    SMALL("SMALL", "Small", 18f, 0.042f),
    MEDIUM("MEDIUM", "Medium (TV Default)", 23f, 0.055f),
    LARGE("LARGE", "Large", 28f, 0.068f),
    EXTRA_LARGE("EXTRA_LARGE", "Extra Large", 34f, 0.082f);

    companion object {
        fun fromId(id: String?): VodSubtitleFontSize {
            return values().firstOrNull { it.id.equals(id?.trim(), ignoreCase = true) } ?: MEDIUM
        }
    }
}

enum class VodSubtitleStylePreset(
    val id: String,
    val label: String,
    val foregroundColor: Int,
    val backgroundColor: Int,
    val edgeColor: Int
) {
    CINEMA_GLASS("CINEMA_GLASS", "Cinema Glass (White on Dark)", 0xFFFFFFFF.toInt(), 0xB8050A14.toInt(), 0xFF000000.toInt()),
    HIGH_CONTRAST_YELLOW("HIGH_CONTRAST_YELLOW", "TV Yellow + Outline", 0xFFFDE047.toInt(), 0x99000000.toInt(), 0xFF000000.toInt()),
    PURE_WHITE_OUTLINE("PURE_WHITE_OUTLINE", "White Outline (No Box)", 0xFFFFFFFF.toInt(), 0x00000000, 0xFF000000.toInt()),
    CLEAN_CYAN("CLEAN_CYAN", "Neon Cyan Soft Box", 0xFFE0F2FE.toInt(), 0xAA081426.toInt(), 0xFF000000.toInt());

    companion object {
        fun fromId(id: String?): VodSubtitleStylePreset {
            return values().firstOrNull { it.id.equals(id?.trim(), ignoreCase = true) } ?: CINEMA_GLASS
        }
    }
}

data class VodQualityOption(
    val id: String,
    val label: String,
    val height: Int,
    val width: Int,
    val bitrateBps: Int,
    val groupIndex: Int,
    val trackIndex: Int,
    val isAuto: Boolean = false,
    val isSelected: Boolean = false,
    val isAvailable: Boolean = true
) {
    fun bitrateBadge(): String {
        if (bitrateBps <= 0) return ""
        val mbps = bitrateBps / 1_000_000.0
        return if (mbps >= 1.0) {
            String.format(Locale.ROOT, "%.1f Mbps", mbps)
        } else {
            "${(bitrateBps / 1000).coerceAtLeast(1)} kbps"
        }
    }
}

data class VodAudioTrackOption(
    val id: String,
    val label: String,
    val languageCode: String,
    val languageDisplay: String,
    val codecName: String,
    val channelLayout: String,
    val channelCount: Int,
    val bitrateBps: Int,
    val groupIndex: Int,
    val trackIndex: Int,
    val isAuto: Boolean = false,
    val isSupported: Boolean = true,
    val isSelected: Boolean = false
)

data class VodSubtitleTrackOption(
    val id: String,
    val label: String,
    val languageCode: String,
    val languageDisplay: String,
    val mimeType: String,
    val groupIndex: Int,
    val trackIndex: Int,
    val isOff: Boolean = false,
    val isExternal: Boolean = false,
    val isSelected: Boolean = false
)

enum class VodErrorCategory(val title: String, val isRetryable: Boolean) {
    INVALID_URL("Invalid Stream URL", false),
    AUTH_EXPIRED("Account Auth / Expired (401/403)", false),
    NOT_FOUND("Content Unavailable (404/410)", false),
    RATE_LIMITED("Server Rate Limit (429)", true),
    SERVER_ERROR("Provider Server Error (5xx)", true),
    NETWORK_INTERRUPTED("Network Connection Lost", true),
    MANIFEST_ERROR("Stream Manifest Error (HLS/DASH)", true),
    UNSUPPORTED_CODEC("Unsupported Video/Audio Format", false),
    DECODER_FAILURE("Hardware Decoder Error", true),
    AUDIO_TRACK_FAILURE("Audio Track Playback Error", true),
    SUBTITLE_FAILURE("Subtitle Track Error", false),
    CORRUPT_MEDIA("Corrupt or Unreadable Media", false),
    UNKNOWN("Playback Error", true)
}

data class VodErrorInfo(
    val category: VodErrorCategory,
    val httpCode: Int = 0,
    val title: String,
    val message: String,
    val canRetry: Boolean,
    val retryCount: Int = 0,
    val maxRetries: Int = 3
)

enum class VodPlaybackStatus {
    INITIALIZING,
    BUFFERING,
    PLAYING,
    PAUSED,
    ENDED,
    ERROR
}

data class VodPlaybackState(
    val status: VodPlaybackStatus = VodPlaybackStatus.INITIALIZING,
    val isPlaying: Boolean = false,
    val isBuffering: Boolean = true,
    val positionMs: Long = 0L,
    val bufferedPositionMs: Long = 0L,
    val durationMs: Long = 0L,
    val isSeekable: Boolean = false,
    val isLiveLike: Boolean = false,
    val playbackSpeed: VodPlaybackSpeed = VodPlaybackSpeed.SPEED_1_0,
    val aspectRatio: VodAspectRatioMode = VodAspectRatioMode.FIT,
    val currentQualityLabel: String = "Auto",
    val isAutoQuality: Boolean = true,
    val isAdaptiveStream: Boolean = false,
    val currentAudioLabel: String = "Default",
    val currentSubtitleLabel: String = "Off",
    val subtitleDelayMs: Int = 0,
    val errorInfo: VodErrorInfo? = null,
    val autoNextVisible: Boolean = false,
    val autoNextCountdownSec: Int = 0
)

data class VodEpisodeNavItem(
    val episodeId: String,
    val seriesId: String,
    val seriesKey: String,
    val seriesTitle: String,
    val seasonNumber: Int,
    val episodeNumber: Int,
    val episodeTitle: String,
    val streamUrl: String,
    val posterUrl: String = "",
    val durationLabel: String = "",
    val plot: String = "",
    val containerExtension: String = ""
) {
    fun seasonEpisodeBadge(): String {
        val s = seasonNumber.toString().padStart(2, '0')
        val e = episodeNumber.toString().padStart(2, '0')
        return "S${s}E${e}"
    }

    fun toJsonObject(): JSONObject = JSONObject().apply {
        put("id", episodeId)
        put("sid", seriesId)
        put("sk", seriesKey)
        put("st", seriesTitle)
        put("sn", seasonNumber)
        put("en", episodeNumber)
        put("et", episodeTitle)
        put("u", streamUrl)
        put("p", posterUrl)
        put("d", durationLabel)
        put("pl", plot)
        put("ext", containerExtension)
    }

    companion object {
        fun fromJsonObject(obj: JSONObject): VodEpisodeNavItem? {
            val id = obj.optString("id").trim()
            val url = obj.optString("u").trim()
            if (id.isEmpty() || url.isEmpty()) return null
            return VodEpisodeNavItem(
                episodeId = id,
                seriesId = obj.optString("sid"),
                seriesKey = obj.optString("sk"),
                seriesTitle = obj.optString("st"),
                seasonNumber = obj.optInt("sn", 1),
                episodeNumber = obj.optInt("en", 1),
                episodeTitle = obj.optString("et"),
                streamUrl = url,
                posterUrl = obj.optString("p"),
                durationLabel = obj.optString("d"),
                plot = obj.optString("pl"),
                containerExtension = obj.optString("ext")
            )
        }

        fun encodeList(items: List<VodEpisodeNavItem>): String {
            val arr = JSONArray()
            for (item in items) {
                arr.put(item.toJsonObject())
            }
            return arr.toString()
        }

        fun decodeList(rawJson: String?): List<VodEpisodeNavItem> {
            if (rawJson.isNullOrBlank()) return emptyList()
            return runCatching {
                val arr = JSONArray(rawJson)
                val out = ArrayList<VodEpisodeNavItem>(arr.length())
                for (i in 0 until arr.length()) {
                    val obj = arr.optJSONObject(i) ?: continue
                    fromJsonObject(obj)?.let { out.add(it) }
                }
                out
            }.getOrDefault(emptyList())
        }
    }
}

data class VodLaunchPayload(
    val contentType: VodContentType,
    val contentId: String,
    val streamUrl: String,
    val title: String,
    val subtitleLine: String = "",
    val category: String = "",
    val posterUrl: String = "",
    val backdropUrl: String = "",
    val rating: String = "",
    val releaseYear: String = "",
    val durationLabel: String = "",
    val containerExtension: String = "",
    val resumePositionMs: Long = 0L,
    val accountScope: String = "default",
    val seriesKey: String = "",
    val seriesId: String = "",
    val seriesTitle: String = "",
    val seasonNumber: Int = 0,
    val episodeNumber: Int = 0,
    val episodes: List<VodEpisodeNavItem> = emptyList(),
    val externalSubtitleUrl: String = "",
    val externalSubtitleLanguage: String = "en"
)

object VodTimeFormatter {
    fun formatMs(ms: Long): String {
        if (ms <= 0L) return "00:00"
        val totalSeconds = ms / 1000L
        val hours = totalSeconds / 3600L
        val minutes = (totalSeconds % 3600L) / 60L
        val seconds = totalSeconds % 60L
        return if (hours > 0L) {
            String.format(Locale.ROOT, "%d:%02d:%02d", hours, minutes, seconds)
        } else {
            String.format(Locale.ROOT, "%02d:%02d", minutes, seconds)
        }
    }

    fun formatSignedDeltaMs(deltaMs: Long): String {
        val sign = if (deltaMs >= 0L) "+" else "-"
        val absMs = kotlin.math.abs(deltaMs)
        return "$sign${formatMs(absMs)}"
    }
}
